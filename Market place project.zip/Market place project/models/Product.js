const mongoose = require("mongoose");
const User = require("./User");

const ProductSchema = new mongoose.Schema(
    {
        user_id:{
            type:mongoose.Schema.Types.ObjectId,
            ref:'User'
        },
        type:{
            type:String,
            required:true
        },
        name:{
            type:String,
            min:2,
            required:true
        },
        quantity:{
            type:Number,
            default:null
        },
        sold_date:{
            type:Date,
            default:null
        },
        post_date:{
            type:Date,
            required:true,
            default:null
        },
        status:{
            type:String,
            default:null
        },
        owner_id:{
            type:String,
            default:null
        },
        product_image:{
            // type:String,
            data: Buffer, contentType: String,
            //default:null
        },
        price:{
            type:Number,
            default:null
        },
        description:{
            type:String,
            default:null
        }

     }//,
// { timestamps: true }
);

module.exports = mongoose.model("Product",ProductSchema);
module.exports=ProductSchema;
