const mongoose = require("mongoose");
//const connection1= require('../app');
const UserSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      min: 3,
      max: 20,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      max: 50,
      unique: true,
    },
    password: {
      type: String,
      required: true,
      min: 6,
    },
    balance:{
        type:Number,
        default:null
    },
    mobile_number:{
        type:String,
        default:null
    },
    sold_item_income:{
        type:Number,
        default:null
    },
    purchased_item_cost:{
        type:Number,
        default:null
    },
    region:{
        type:String,
        required:true
    }
    
  }//,
  // { timestamps: true }
);

module.exports = mongoose.model("User", UserSchema);
module.exports=UserSchema;

// const userModel1 = connection1.model("User",UserSchema);
// module.exports = userModel1;