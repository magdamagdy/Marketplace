const router = require('express').Router();
const bcrypt = require ('bcrypt');
const mongoose = require('mongoose');
const UserSchema = require("../models/User");

// //const jwt = require ('jsonwebtoken');
// //const cookieParser = require('cookie-parser');
// const {createToken, createTokens}=require('./JWT');

//////////////
//connect to first server
const connection1 = mongoose.createConnection(
	"mongodb+srv://server1:server1@cluster0.vtt0a.mongodb.net/server1?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server1  is connected successfully `);
	}
);
const userModel1 = connection1.model("User",UserSchema);


//connect to second server
const connection2 = mongoose.createConnection(
	"mongodb+srv://server2:server2@cluster0.uhp2r.mongodb.net/server2?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server2  is connected successfully `);
	}
);

const userModel2 = connection2.model("User",UserSchema);

//connect to third server
const connection3 = mongoose.createConnection(
	"mongodb+srv://server3:server3@cluster0.7v7gj.mongodb.net/server3?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server3  is connected successfully `);
	}
);

const userModel3 = connection3.model("User",UserSchema);

//connect to fourth server
// const connection4 = mongoose.createConnection(
// 	"mongodb+srv://server4:server4@cluster0.qgmaf.mongodb.net/server4?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server4  is connected successfully `);
// 	}
// );

// const userModel4 = connection4.model("User",UserSchema);

// //connect to fifth server
// const connection5 = mongoose.createConnection(
// 	"mongodb+srv://server5:server5@cluster0.rkzi3.mongodb.net/server5?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server5  is connected successfully `);
// 	}
// );

// const userModel5 = connection5.model("User",UserSchema);

// const connection6 = mongoose.createConnection(
// 	"mongodb+srv://server6:server6@cluster0.upnh4.mongodb.net/server6?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server6  is connected successfully `);
// 	}
// );

// const userModel6 = connection6.model("User",UserSchema);
//////////////


//register 
router.post('/register',async(req,res)=>{
    try{
        //generate new password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password,salt)//to hash pass
        // create new user 
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
          newUser = await userModel1.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          // newUser = await userModel4.create({
          //   username:req.body.username,
          //   email:req.body.email,
          //   region:req.body.region,
          //   password:hashedPassword,
          //   mobile_number:req.body.mobile_number
          // });
        }

      else if (req.body.region === 'North America' || req.body.region === 'South America')
      {
          newUser = await userModel2.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          // newUser = await userModel5.create({
          //   username:req.body.username,
          //   email:req.body.email,
          //   region:req.body.region,
          //   password:hashedPassword,
          //   mobile_number:req.body.mobile_number
          // });
      }
      else 
      {
          newUser = await userModel3.create({
            username:req.body.username,
            email:req.body.email,
            region:req.body.region,
            password:hashedPassword,
            mobile_number:req.body.mobile_number
          });
          // newUser = await userModel6.create({
          //   username:req.body.username,
          //   email:req.body.email,
          //   region:req.body.region,
          //   password:hashedPassword,
          //   mobile_number:req.body.mobile_number
          // });
      }
      res.status(200).json(/*newUser*/"Success"); /*.send("Success");*/  
    }
      
        //const accessToken = createTokens(user);

        // res.cookie('access-token', accessToken,{
        //     maxAge: 60*60*24*30*1000  //30days
        // });

    catch(err){
        res.status(500).json(err);
        console.log (err);
    }
    
});

//login
router.post("/login", async (req, res) => {
    try {
      if(req.body.region === 'Asia' || req.body.region === 'Europe'){
        //search in basic db server ==>server1
        const user = await userModel1.findOne({ email: req.body.email });
        !user && res.status(404).json("user not found");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password)
        !validPassword && res.status(400).json("wrong password");

        // if(!user) // if server1 is down search in its replica ==>server4
        // {
        //   const user = await userModel4.findOne({ email: req.body.email });
        //   !user && res.status(404).json("user not found");
      
        //   const validPassword = await bcrypt.compare(req.body.password, user.password)
        //   !validPassword && res.status(400).json("wrong password");
        // }
        res.status(200).json(user);
      }
      else if (req.body.region === 'North America' || req.body.region === 'South America')
      {
        //search in basic db server ==>server2
        const user = await userModel2.findOne({ email: req.body.email });
        !user && res.status(404).json("user not found");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password)
        !validPassword && res.status(400).json("wrong password");

        // if(!user) // if server1 is down search in its replica ==>server5
        // {
        //   const user = await userModel5.findOne({ email: req.body.email });
        //   !user && res.status(404).json("user not found");
      
        //   const validPassword = await bcrypt.compare(req.body.password, user.password)
        //   !validPassword && res.status(400).json("wrong password");
        // }
        res.status(200).json(user);
      }
      else
      {
        //search in basic db server ==>server3
        const user = await userModel3.findOne({ email: req.body.email });
        !user && res.status(404).json("user not found");
    
        const validPassword = await bcrypt.compare(req.body.password, user.password)
        !validPassword && res.status(400).json("wrong password");

        // if(!user) // if server1 is down search in its replica ==>server6
        // {
        //   const user = await userModel6.findOne({ email: req.body.email });
        //   !user && res.status(404).json("user not found");
      
        //   const validPassword = await bcrypt.compare(req.body.password, user.password)
        //   !validPassword && res.status(400).json("wrong password");
        // } 
        res.status(200).json(user);
      }
      // res.status(200).json(user);

    } catch (err) {
     // res.status(500).json(err);
      //console.log(err);
    }
  });
module.exports = router;