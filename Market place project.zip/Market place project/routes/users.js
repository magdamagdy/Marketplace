const router = require('express').Router();
//const userModel1 = require('../models/User');
const bcrypt = require ('bcrypt');
//const userModel1= require('../app');
const mongoose = require('mongoose');
const UserSchema = require("../models/User");
const ProductSchema = require("../models/Product");

//////////////
//connect to first server
const connection1 = mongoose.createConnection(
	"mongodb+srv://server1:server1@cluster0.vtt0a.mongodb.net/server1?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server1  is connected successfully `);
	}
);
const userModel1 = connection1.model("User",UserSchema);
const productModel1 = connection1.model("Product",ProductSchema);

//connect to second server
const connection2 = mongoose.createConnection(
	"mongodb+srv://server2:server2@cluster0.uhp2r.mongodb.net/server2?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server2  is connected successfully `);
	}
);
const userModel2 = connection2.model("User",UserSchema);
const productModel2 = connection2.model("Product",ProductSchema);

//connect to third server
const connection3 = mongoose.createConnection(
	"mongodb+srv://server3:server3@cluster0.7v7gj.mongodb.net/server3?retryWrites=true&w=majority",
	{ useNewUrlParser: true, useUnifiedTopology: true },
	() => {
		console.log(`server3  is connected successfully `);
	}
);
const userModel3 = connection3.model("User",UserSchema);
const productModel3 = connection3.model("Product",ProductSchema);

//connect to fourth server
// const connection4 = mongoose.createConnection(
// 	"mongodb+srv://server4:server4@cluster0.qgmaf.mongodb.net/server4?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server4  is connected successfully `);
// 	}
// );

// const userModel4 = connection4.model("User",UserSchema);

// //connect to fifth server
// const connection5 = mongoose.createConnection(
// 	"mongodb+srv://server5:server5@cluster0.rkzi3.mongodb.net/server5?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server5  is connected successfully `);
// 	}
// );

// const userModel5 = connection5.model("User",UserSchema);

// const connection6 = mongoose.createConnection(
// 	"mongodb+srv://server6:server6@cluster0.upnh4.mongodb.net/server6?retryWrites=true&w=majority",
// 	{ useNewUrlParser: true, useUnifiedTopology: true },
// 	() => {
// 		console.log(`server6  is connected successfully `);
// 	}
// );

// const userModel6 = connection6.model("User",UserSchema);
//////////////



// router.post('/add',async(req,res)=>{
//     try{
//         //generate new password
//         const salt = await bcrypt.genSalt(10);
//         const hashedPassword = await bcrypt.hash(req.body.password,salt)//to hash pass
//         // create new user 
//         if(req.body.region === 'Asia' || req.body.region === 'Europe'){
//             newUser = await userModel1.create({
//                 username:req.body.username,
//                 email:req.body.email,
//                 region:req.body.region,
//                 password:hashedPassword
//             });
//         }

//         else if (req.body.region === 'North America' || req.body.region === 'South America')
//         {
//             newUser = await userModel2.create({
//                 username:req.body.username,
//                 email:req.body.email,
//                 region:req.body.region,
//                 password:hashedPassword
//             });
//         }
//         else 
//         {
//             newUser = await userModel3.create({
//                 username:req.body.username,
//                 email:req.body.email,
//                 region:req.body.region,
//                 password:hashedPassword
//             });
//         }
//         //save user & respond
//         //const user = await newUser.save();
//         res.status(200).json(newUser);
        
//     }
//     catch(err){
//         res.status(500).json(err);
//         console.log(err);
//     }
    
// });

    //get user by Id
router.get('/getbyId', async (req, res) => {
    try {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findById(req.body.id);
            // if(!user)
            // {
            //     const user = await userModel4.findById(req.body.id);
            // }
            res.status(200).json(user); 
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            // if(!user)
            // {
            //     const user = await userModel5.findById(req.body.id);
            // }
            res.status(200).json(user); 
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            // if(!user)
            // {
            //     const user = await userModel6.findById(req.body.id);
            // }
            if(user)
            res.status(200).json(user);
            else
            res.status(200).json("user not found");
        }
                             
    } 
    catch (err) {
      res.status(500).json("user not found");
      console.log(err);
    }
  });


  //Edit user
router.put("/edit", async (req, res) => {    
    if (req.body.password) {
    try {
        const salt = await bcrypt.genSalt(10);
        req.body.password = await bcrypt.hash(req.body.password, salt);
    } catch (err) {
        return res.status(500).json(err); 
    }
    }
    try {
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const user = await userModel1.findByIdAndUpdate(req.body.id, {
                $set: req.body, // to set all inputs inside this body (the body written in postman)
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findByIdAndUpdate(req.body.id, {
                $set: req.body,
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
        else
        {
            const user = await userModel3.findByIdAndUpdate(req.body.id, {
                $set: req.body,
            });
            if(user)
            res.status(200).json("Success");
            else 
            res.status(200).json("user not found");
        }
    }
    catch (err) {
    res.status(500).json("user not found");
    console.log(err);
    }
    
  });

  // get purchased products for specific user 
router.get('/purchased', async (req, res) => {
    try{
        if(req.body.region === 'Asia' || req.body.region === 'Europe')
        {
            const products = await productModel1.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            if(products)
            res.status(200).json(products);
            else 
            res.status(200).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const products = await productModel2.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            if(products)
            res.status(200).json(products);
            else 
            res.status(200).json("user not found");
        }
        else
        {
            const products = await productModel3.find({
                "user_id": req.body.id,
                "status": "purchased"
              });
            if(products)
            res.status(200).json(products);
            else 
            res.status(200).json("user not found");
        }
    }
    catch (err) {
        res.status(500).json("user not found");
        console.log(err);
        }
});

    //add new product
router.post('/products/add', async (req, res) => {
    try
    {
        if(req.body.region === 'Asia' || req.body.region === 'Europe'){
            const user = await userModel1.findById(req.body.id);
            if(user){
                newPouduct = await productModel1.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description//,
                //product_image:
                });
                res.status(200).json("Success");
            }
            else
            res.status(500).json("user not found");
        }
        else if (req.body.region === 'North America' || req.body.region === 'South America')
        {
            const user = await userModel2.findById(req.body.id);
            if(user){
                newPouduct = await productModel2.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description//,
                //product_image:
                });
                res.status(200).json("Success");
            }
            else
            res.status(500).json("user not found");
        }
        else
        {
            const user = await userModel3.findById(req.body.id);
            if(user){
                newPouduct = await productModel3.create({
                user_id:req.body.id,
                type:req.body.type,
                name:req.body.name,
                quantity:req.body.quantity,
                post_date:Date.now(),
                status:"available",
                price:req.body.price,
                description:req.body.description//,
                //product_image:
                });
                res.status(200).json("Success");
            }
            else
            res.status(500).json("user not found");
        }
    }
    catch (err) {
        res.status(500).json("user not found");
        console.log(err);
        }
    });

    //filter product ny name 
    router.get('/products/filterbyname', async (req, res) => {
        try {
            const products =[];
            const products1 = await productModel1.find({ name: { $regex : req.body.name} });
            if(products1)
            products.push(products1);

            const products2 = await productModel2.find({ name: { $regex : req.body.name} });
            if(products2)
            products.push(products2);

            const products3 = await productModel3.find({ name: { $regex : req.body.name} });
            if(products3)
            products.push(products3);

            res.status(200).json(products);                     
        } 
        catch (err) {
          res.status(500).json("name not found");
          console.log(err);
        }
      });



module.exports=router;

